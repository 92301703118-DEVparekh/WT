// Hotel data for each destination with prices and availability
const hotels = {
    georgia: [
        { name: 'Tbilisi Suites', price: 150, available: true },
        { name: 'Georgia Palace', price: 180, available: false }
    ],
    dubai: [
        { name: 'Burj Al Arab', price: 500, available: true },
        { name: 'Atlantis The Palm', price: 400, available: true }
    ],
    oman: [
        { name: 'Shangri-La Al Husn', price: 300, available: true },
        { name: 'Al Bustan Palace', price: 350, available: false }
    ],
    malaysia: [
        { name: 'The Ritz-Carlton', price: 250, available: true },
        { name: 'Shangri-La Kuala Lumpur', price: 220, available: true }
    ],
    europe: [
        { name: 'The Ritz London', price: 450, available: true },
        { name: 'Hotel de Paris Monte-Carlo', price: 550, available: false }
    ],
    'southeast-asia': [
        { name: 'Marina Bay Sands', price: 600, available: true },
        { name: 'Mandarin Oriental Bangkok', price: 500, available: true }
    ]
};

// Populate hotel options based on destination
document.getElementById('destination').addEventListener('change', function() {
    const selectedDestination = this.value;
    const hotelSelect = document.getElementById('hotel');
    
    // Clear existing options
    hotelSelect.innerHTML = '<option value="" disabled selected>Select a hotel</option>';

    // Get hotels for selected destination
    const destinationHotels = hotels[selectedDestination];
    
    // Populate hotel options
    destinationHotels.forEach(hotel => {
        const option = document.createElement('option');
        option.value = hotel.name;
        option.textContent = `${hotel.name} - $${hotel.price} per night - ${hotel.available ? 'Available' : 'Fully Booked'}`;
        option.disabled = !hotel.available;  // Disable fully booked hotels
        hotelSelect.appendChild(option);
    });
});

// Handle form submission
document.getElementById('bookingForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const destination = document.getElementById('destination').value;
    const hotel = document.getElementById('hotel').value;
    const travelers = document.getElementById('travelers').value;
    const date = document.getElementById('date').value;

    // Redirect to confirmation page with query parameters
    window.location.href = `confirmation.html?destination=${destination}&hotel=${hotel}&travelers=${travelers}&date=${date}`;
});

// Function to retrieve query parameters from the URL
function getQueryParams() {
    const params = new URLSearchParams(window.location.search);
    return {
        destination: params.get('destination'),
        hotel: params.get('hotel'),
        travelers: params.get('travelers'),
        date: params.get('date')
    };
}

// Display booking details and save the booking to local storage
document.addEventListener('DOMContentLoaded', function() {
    const { destination, hotel, travelers, date } = getQueryParams();

    const bookingDetails = `
        You have booked a trip to ${destination.charAt(0).toUpperCase() + destination.slice(1)}.<br>
        Hotel: ${hotel}.<br>
        Number of travelers: ${travelers}.<br>
        Travel date: ${date}.
    `;
    
    document.getElementById('bookingDetails').innerHTML = bookingDetails;

    // Store booking in localStorage
    const newBooking = { destination, hotel, travelers, date };
    let bookings = JSON.parse(localStorage.getItem('bookings')) || [];
    bookings.push(newBooking);
    localStorage.setItem('bookings', JSON.stringify(bookings));
});

// Function to go back to the booking page
function goBack() {
    window.location.href = 'booking.html';
}

// Function to go to the home page
function goHome() {
    window.location.href = 'index.html';
}

// Function to view bookings
function viewBookings() {
    window.location.href = 'mybookings.html'; // Redirect to the bookings page
}

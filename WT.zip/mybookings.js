// Function to display all bookings from localStorage
document.addEventListener('DOMContentLoaded', function() {
    const bookingList = document.getElementById('bookingList');
    const bookings = JSON.parse(localStorage.getItem('bookings')) || [];

    if (bookings.length === 0) {
        bookingList.innerHTML = '<p>No bookings found.</p>';
    } else {
        bookings.forEach((booking, index) => {
            const bookingItem = document.createElement('div');
            bookingItem.classList.add('booking-item');
            bookingItem.innerHTML = `
                <h3>Booking ${index + 1}</h3>
                <p>Destination: ${booking.destination.charAt(0).toUpperCase() + booking.destination.slice(1)}</p>
                <p>Hotel: ${booking.hotel}</p>
                <p>Travelers: ${booking.travelers}</p>
                <p>Date: ${booking.date}</p>
            `;
            bookingList.appendChild(bookingItem);
        });
    }
});

// Function to go to the home page
function goHome() {
    window.location.href = 'index.html';
}

// Function to go back to the booking page
function goBack() {
    window.location.href = 'booking.html';
}
